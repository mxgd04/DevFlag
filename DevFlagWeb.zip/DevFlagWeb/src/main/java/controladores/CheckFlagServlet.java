package controladores;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "CheckFlagServlet", urlPatterns = {"/CheckFlagServlet"})
public class CheckFlagServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mariadb://localhost:3306/devflag";
    private static final String DB_USER = "netbeans";
    private static final String DB_PASS = "12345";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);
        if (sesion == null || sesion.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect("login.html");
            return;
        }

        String username = (String) sesion.getAttribute("usuarioLogueado");
        String idRetoStr = request.getParameter("idReto");
        String flagSubida = request.getParameter("flagSubida");

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            int idUsuario = -1;
            PreparedStatement psUser = con.prepareStatement("SELECT id FROM Usuario WHERE username = ?");
            psUser.setString(1, username);
            ResultSet rsUser = psUser.executeQuery();
            if (rsUser.next()) idUsuario = rsUser.getInt("id");
            rsUser.close(); psUser.close();

            String flagReal = null;
            int puntosReto = 0;
            PreparedStatement psReto = con.prepareStatement("SELECT flag, puntos FROM Reto WHERE id = ?");
            psReto.setInt(1, Integer.parseInt(idRetoStr));
            ResultSet rsReto = psReto.executeQuery();
            if (rsReto.next()) {
                flagReal = rsReto.getString("flag");
                puntosReto = rsReto.getInt("puntos");
            }
            rsReto.close(); psReto.close();

            if (flagReal != null && flagReal.equals(flagSubida.trim())) {
                PreparedStatement psCheck = con.prepareStatement("SELECT id FROM Resolucion WHERE id_usuario = ? AND id_reto = ?");
                psCheck.setInt(1, idUsuario);
                psCheck.setInt(2, Integer.parseInt(idRetoStr));
                if (psCheck.executeQuery().next()) {
                    response.sendRedirect("challenge.jsp?id=" + idRetoStr + "&error=ya_resuelto");
                } else {
                    con.prepareStatement("INSERT INTO Resolucion (id_usuario, id_reto, correcta) VALUES ("+idUsuario+","+idRetoStr+", 1)").executeUpdate();
                    con.prepareStatement("UPDATE Usuario SET xp_total = xp_total + "+puntosReto+" WHERE id = "+idUsuario).executeUpdate();
                    response.sendRedirect("challenge.jsp?id=" + idRetoStr + "&success=flag_correcta");
                }
            } else {
                response.sendRedirect("challenge.jsp?id=" + idRetoStr + "&error=flag_incorrecta");
            }
            con.close();
        } catch (Exception e) {
            response.sendRedirect("challenge.jsp?id=" + idRetoStr + "&error=fallo_servidor");
        }
    }
}