package controladores;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String user = request.getParameter("username");
        String pass = request.getParameter("password");

        String hashPassword = cifrarSHA256(pass);

        String url = "jdbc:mariadb://localhost:3306/devflag";
        String usuarioDB = "netbeans";
        String passDB = "12345";
        
        String sql = "SELECT id, username FROM Usuario WHERE username = ? AND password_hash = ?";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            Connection conexion = DriverManager.getConnection(url, usuarioDB, passDB);
            
            PreparedStatement pstmt = conexion.prepareStatement(sql);
            pstmt.setString(1, user);
            pstmt.setString(2, hashPassword);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                
                HttpSession sesion = request.getSession();
                sesion.setAttribute("usuarioLogueado", rs.getString("username"));
                
                response.sendRedirect("dashboard.jsp");
                
            } else {
                response.sendRedirect("login.html?error=credenciales_invalidas");
            }
            
            rs.close();
            pstmt.close();
            conexion.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("login.html?error=fallo_servidor");
        }
    }

    private String cifrarSHA256(String textoPlano) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(textoPlano.getBytes(StandardCharsets.UTF_8));
            
            StringBuilder hexString = new StringBuilder(2 * encodedhash.length);
            for (int i = 0; i < encodedhash.length; i++) {
                String hex = Integer.toHexString(0xff & encodedhash[i]);
                if(hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error crítico de seguridad", e);
        }
    }
}