package controladores;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "ProfileServlet", urlPatterns = {"/ProfileServlet"})
public class ProfileServlet extends HttpServlet {

    private static final String DB_URL  = "jdbc:mariadb://localhost:3306/devflag";
    private static final String DB_USER = "netbeans";
    private static final String DB_PASS = "12345";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);

        if (sesion == null || sesion.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect("login.html");
            return;
        }

        String usernameActual = (String) sesion.getAttribute("usuarioLogueado");
        String action         = request.getParameter("action");

        if ("changeUsername".equals(action)) {
            cambiarUsername(request, response, sesion, usernameActual);
        } else if ("changePassword".equals(action)) {
            cambiarPassword(request, response, sesion, usernameActual);
        } else {
            response.sendRedirect("profile.jsp");
        }
    }

    private void cambiarUsername(HttpServletRequest request, HttpServletResponse response,
                                  HttpSession sesion, String usernameActual)
            throws IOException {

        String newUsername      = request.getParameter("newUsername");
        String currentPassword  = request.getParameter("currentPassword");

        if (newUsername == null || newUsername.trim().isEmpty()) {
            response.sendRedirect("profile.jsp?error=fallo_interno");
            return;
        }

        newUsername = newUsername.trim();
        String hashPass = cifrarSHA256(currentPassword);

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            String sqlCheck = "SELECT id FROM Usuario WHERE username = ? AND password_hash = ?";
            PreparedStatement psCheck = con.prepareStatement(sqlCheck);
            psCheck.setString(1, usernameActual);
            psCheck.setString(2, hashPass);
            ResultSet rs = psCheck.executeQuery();

            if (!rs.next()) {
                rs.close(); psCheck.close(); con.close();
                response.sendRedirect("profile.jsp?error=wrong_password");
                return;
            }
            rs.close();
            psCheck.close();

            String sqlExists = "SELECT id FROM Usuario WHERE username = ?";
            PreparedStatement psExists = con.prepareStatement(sqlExists);
            psExists.setString(1, newUsername);
            ResultSet rsExists = psExists.executeQuery();

            if (rsExists.next()) {
                rsExists.close(); psExists.close(); con.close();
                response.sendRedirect("profile.jsp?error=username_taken");
                return;
            }
            rsExists.close();
            psExists.close();

            String sqlUpdate = "UPDATE Usuario SET username = ? WHERE username = ?";
            PreparedStatement psUpdate = con.prepareStatement(sqlUpdate);
            psUpdate.setString(1, newUsername);
            psUpdate.setString(2, usernameActual);
            psUpdate.executeUpdate();
            psUpdate.close();
            con.close();

            sesion.setAttribute("usuarioLogueado", newUsername);
            response.sendRedirect("profile.jsp?success=username_updated");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("profile.jsp?error=fallo_interno");
        }
    }

    private void cambiarPassword(HttpServletRequest request, HttpServletResponse response,
                                  HttpSession sesion, String usernameActual)
            throws IOException {

        String currentPassword  = request.getParameter("currentPassword");
        String newPassword      = request.getParameter("newPassword");
        String confirmPassword  = request.getParameter("confirmPassword");

        if (newPassword == null || !newPassword.equals(confirmPassword)) {
            response.sendRedirect("profile.jsp?error=passwords_no_coinciden");
            return;
        }

        String hashActual = cifrarSHA256(currentPassword);
        String hashNueva  = cifrarSHA256(newPassword);

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            String sqlCheck = "SELECT id FROM Usuario WHERE username = ? AND password_hash = ?";
            PreparedStatement psCheck = con.prepareStatement(sqlCheck);
            psCheck.setString(1, usernameActual);
            psCheck.setString(2, hashActual);
            ResultSet rs = psCheck.executeQuery();

            if (!rs.next()) {
                rs.close(); psCheck.close(); con.close();
                response.sendRedirect("profile.jsp?error=wrong_password");
                return;
            }
            rs.close();
            psCheck.close();

            String sqlUpdate = "UPDATE Usuario SET password_hash = ? WHERE username = ?";
            PreparedStatement psUpdate = con.prepareStatement(sqlUpdate);
            psUpdate.setString(1, hashNueva);
            psUpdate.setString(2, usernameActual);
            psUpdate.executeUpdate();
            psUpdate.close();
            con.close();

            response.sendRedirect("profile.jsp?success=password_updated");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("profile.jsp?error=fallo_interno");
        }
    }

    private String cifrarSHA256(String textoPlano) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(textoPlano.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder(2 * hash.length);
            for (byte b : hash) {
                String h = Integer.toHexString(0xff & b);
                if (h.length() == 1) hex.append('0');
                hex.append(h);
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error de cifrado", e);
        }
    }
}