package controladores;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "RegisterServlet", urlPatterns = {"/RegisterServlet"})
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String user = request.getParameter("username");
        String email = request.getParameter("email");
        String pass = request.getParameter("password");
        String confirm = request.getParameter("confirm");

        if (pass == null || !pass.equals(confirm)) {
            response.sendRedirect("signup.html?error=passwords_no_coinciden");
            return;
        }

        String hashPassword = cifrarSHA256(pass);

        String url = "jdbc:mariadb://localhost:3306/devflag";
        String usuarioDB = "netbeans";
        String passDB = "12345";
        
        String sql = "INSERT INTO Usuario (username, email, password_hash) VALUES (?, ?, ?)";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            Connection conexion = DriverManager.getConnection(url, usuarioDB, passDB);
            
            PreparedStatement pstmt = conexion.prepareStatement(sql);
            pstmt.setString(1, user);
            pstmt.setString(2, email);
            pstmt.setString(3, hashPassword); 
            
            pstmt.executeUpdate();
            
            pstmt.close();
            conexion.close();

            response.sendRedirect("login.html?registro=exito");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("signup.html?error=fallo_interno");
        }
    }

    private String cifrarSHA256(String textoPlano) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(textoPlano.getBytes(StandardCharsets.UTF_8));
            
            StringBuilder hexString = new StringBuilder(2 * encodedhash.length);
            for (int i = 0; i < encodedhash.length; i++) {
                String hex = Integer.toHexString(0xff & encodedhash[i]);
                if(hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error fatal de cifrado", e);
        }
    }
}