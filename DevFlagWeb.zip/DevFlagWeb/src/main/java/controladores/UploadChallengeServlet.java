package controladores;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, 
    maxFileSize = 1024 * 1024 * 50,      
    maxRequestSize = 1024 * 1024 * 50    
)
@WebServlet(name = "UploadChallengeServlet", urlPatterns = {"/UploadChallengeServlet"})
public class UploadChallengeServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mariadb://localhost:3306/devflag";
    private static final String DB_USER = "netbeans";
    private static final String DB_PASS = "12345";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);
        if (sesion == null || sesion.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect("login.html");
            return;
        }

        String username = (String) sesion.getAttribute("usuarioLogueado");

        String titulo = request.getParameter("titulo");
        String descripcion = request.getParameter("descripcion");
        String flag = request.getParameter("flag");
        String dificultad = request.getParameter("dificultad");
        int puntos = Integer.parseInt(request.getParameter("puntos"));
        int idCategoria = Integer.parseInt(request.getParameter("id_categoria"));
        String tags = request.getParameter("tags");

        Part filePart = request.getPart("archivo");
        String dbFilePath = null; 

        if (filePart != null && filePart.getSize() > 0) {
            String originalName = filePart.getSubmittedFileName();
            String uniqueName = UUID.randomUUID().toString() + "_" + originalName;

            String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdir();

            File file = new File(uploadPath + File.separator + uniqueName);
            try (InputStream input = filePart.getInputStream()) {
                Files.copy(input, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
            
            dbFilePath = "uploads/" + uniqueName;
        }

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            int idAutor = -1;
            PreparedStatement psUser = con.prepareStatement("SELECT id FROM Usuario WHERE username = ?");
            psUser.setString(1, username);
            ResultSet rsUser = psUser.executeQuery();
            if (rsUser.next()) {
                idAutor = rsUser.getInt("id");
            }
            rsUser.close();
            psUser.close();

            String sqlInsert = "INSERT INTO Reto (titulo, descripcion, flag, puntos, dificultad, id_categoria, tags, archivo_url, id_autor) "
                             + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement psReto = con.prepareStatement(sqlInsert);
            psReto.setString(1, titulo);
            psReto.setString(2, descripcion);
            psReto.setString(3, flag);
            psReto.setInt(4, puntos);
            psReto.setString(5, dificultad);
            psReto.setInt(6, idCategoria);
            psReto.setString(7, tags);
            psReto.setString(8, dbFilePath); 
            psReto.setInt(9, idAutor);

            psReto.executeUpdate();
            psReto.close();
            con.close();

            response.sendRedirect("dashboard.jsp?success=reto_creado");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("addChallenge.jsp?error=fallo_servidor");
        }
    }
}