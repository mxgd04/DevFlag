<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); 
    response.setHeader("Pragma", "no-cache"); 
    response.setDateHeader("Expires", 0); 

    if (session == null || session.getAttribute("usuarioLogueado") == null) {
        response.sendRedirect("login.html");
    }
    
%>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>DevFlag – Add Challenge</title>
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="styles.css"/>
  <link rel="stylesheet" href="addChallenge.css"/>
</head>
<body>
  
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-icon">&lt;/&gt;</div>
      <div class="logo-text">Dev<span>Flag</span></div>
    </div>
    <nav class="nav">
      <a href="index.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M3 12L12 3l9 9"/><path d="M9 21V12h6v9"/>
        </svg>
        Home
      </a>
      <a href="dashboard.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
        </svg>
        Dashboard
      </a>
      <a href="ranking.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/>
        </svg>
        Ranking
      </a>
    </nav>
    <div class="sidebar-footer">
      <div class="profile-menu">
        <div class="profile-dropdown">
          <a href="profile.jsp" class="nav-item">
            <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
              <circle cx="12" cy="7" r="4"/>
            </svg>
            My Profile
          </a>
          <a href="LogoutServlet" class="nav-item" style="color: #e8445a;">
            <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Logout
          </a>
        </div>
      </div>
    </div>
  </aside>
  
  <main class="main">
    <header class="topbar">
      <div class="breadcrumb">
        <a href="index.jsp" class="home-link">Home</a>
        <span class="breadcrumb-sep">/</span>
        <strong>Add Challenge</strong>
      </div>
    </header>
    
    <form action="UploadChallengeServlet" method="post" enctype="multipart/form-data" class="form-layout">
      
      <div class="form-col form-col--main">
        
        <div class="ac-section" style="animation-delay:0.05s">
          <label class="ac-label" for="ch-title">Challenge Title <span class="ac-required">*</span></label>
          <div class="ac-input-wrap">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
            </svg>
            <input type="text" id="ch-title" name="titulo" placeholder="e.g. Advanced Buffer Overflow" maxlength="80" required />
          </div>
        </div>
        
        <div class="ac-section" style="animation-delay:0.10s">
          <label class="ac-label" for="ch-desc">Description <span class="ac-required">*</span></label>
          <div class="ac-textarea-wrap">
            <textarea id="ch-desc" name="descripcion" rows="5" maxlength="600" required placeholder="Describe the objectives, context and what participants need to accomplish..."></textarea>
          </div>
        </div>

        <div class="ac-section" style="animation-delay:0.12s">
          <label class="ac-label" for="ch-flag">Flag <span class="ac-required">*</span></label>
          <div class="ac-input-wrap">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>
            </svg>
            <input type="text" id="ch-flag" name="flag" placeholder="devflag{tH1s_1s_tH3_Fl4g}" maxlength="255" required />
          </div>
        </div>
        
        <div class="ac-row" style="animation-delay:0.15s">
          <div class="ac-section">
            <label class="ac-label">Difficulty <span class="ac-required">*</span></label>
            <div class="pill-group" id="difficulty-group">
              <input type="radio" name="dificultad" id="diff-easy" value="easy" required>
              <label for="diff-easy" class="pill pill--easy">Easy</label>
              
              <input type="radio" name="dificultad" id="diff-medium" value="medium">
              <label for="diff-medium" class="pill pill--medium">Medium</label>
              
              <input type="radio" name="dificultad" id="diff-hard" value="hard">
              <label for="diff-hard" class="pill pill--hard">Hard</label>
            </div>
          </div>
          
          <div class="ac-section">
            <label class="ac-label" for="ch-points">Points (XP) <span class="ac-required">*</span></label>
            <div class="ac-input-wrap">
              <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
              </svg>
              <input type="number" id="ch-points" name="puntos" placeholder="500" min="50" max="5000" step="50" required/>
            </div>
          </div>
        </div>
        
        <div class="ac-section" style="animation-delay:0.20s">
          <label class="ac-label">Category <span class="ac-required">*</span></label>
          <div class="category-grid">
            <input type="radio" name="id_categoria" id="cat-reversing" value="1" required>
            <label for="cat-reversing" class="cat-pill"><span>🔄</span>Reversing</label>
            
            <input type="radio" name="id_categoria" id="cat-crypto" value="2">
            <label for="cat-crypto" class="cat-pill"><span>🔐</span>Cryptography</label>
            
            <input type="radio" name="id_categoria" id="cat-blockchain" value="3">
            <label for="cat-blockchain" class="cat-pill"><span>🧩</span>Steganography</label>
          </div>
        </div>
        
        <div class="ac-section" style="animation-delay:0.25s">
          <label class="ac-label" for="ch-tags">Tags <span class="ac-label-hint">— comma separated</span></label>
          <div class="ac-input-wrap">
            <input type="text" id="ch-tags" name="tags" placeholder="e.g. sql, injection, beginner"/>
          </div>
        </div>
      </div>
      
      <div class="form-col form-col--side">
        <div class="ac-section" style="animation-delay:0.10s">
          <label class="ac-label">Challenge File</label>
          <div class="dropzone" id="dropzone">
            <div class="dropzone-inner" id="dropzone-inner">
              <label class="btn-browse" for="file-input" id="file-label" style="cursor: pointer;">Select File (Optional)</label>             
              <input type="file" id="file-input" name="archivo" accept=".zip,.tar,.gz,.pdf,.md,.txt,.py,.js,.java,.c,.cpp,.exe,.bin" style="display: none;" onchange="handleFileSelect(this)" />
              <p class="dropzone-hint">max 50 MB</p>
              <button type="button" id="btn-remove-file" onclick="removeFile()" style="display: none; align-items: center; gap: 4px; background: none; border: none; color: #e8445a; font-family: var(--font-mono); font-size: 11px; cursor: pointer; margin-top: 6px; letter-spacing: 0.5px; text-transform: uppercase;">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12">
                  <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
                Remove
              </button>
            </div>
          </div>
        </div>
      
      <div class="ac-actions" style="animation-delay:0.30s">
        <a href="dashboard.jsp" class="btn-cancel">Cancel</a>
        <button type="submit" class="btn-publish">
          <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          Publish
        </button>
      </div>
      
    </form>
  </main>
<script>
    function handleFileSelect(input) {
      const label = document.getElementById('file-label');
      const removeBtn = document.getElementById('btn-remove-file');
      
      if (input.files && input.files.length > 0) {
        label.innerText = input.files[0].name;
        removeBtn.style.display = 'flex';
      } else {
        label.innerText = 'Select File (Optional)';
        removeBtn.style.display = 'none';
      }
    }

    function removeFile() {
      const input = document.getElementById('file-input');
      input.value = ''; 
      handleFileSelect(input); 
    }
  </script>
</body>
</html>