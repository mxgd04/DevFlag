<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    String idParam = request.getParameter("id");
    String successMsg = request.getParameter("success");
    String errorMsg = request.getParameter("error");
    
    if (idParam == null || idParam.trim().isEmpty()) {
        response.sendRedirect("index.jsp");
        return;
    }

    String titulo = "", descripcion = "", dificultad = "", tags = "", archivoUrl = "", autor = "Admin";
    int puntos = 0, idCategoria = 0;

    String url = "jdbc:mariadb://localhost:3306/devflag";
    String userDB = "netbeans";
    String passDB = "12345";

    try {
        Class.forName("org.mariadb.jdbc.Driver");
        Connection con = DriverManager.getConnection(url, userDB, passDB);
        
        String sql = "SELECT r.*, u.username FROM Reto r "
                   + "JOIN Usuario u ON r.id_autor = u.id "
                   + "WHERE r.id = ?";
        
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, Integer.parseInt(idParam));
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            titulo = rs.getString("titulo");
            descripcion = rs.getString("descripcion");
            dificultad = rs.getString("dificultad");
            puntos = rs.getInt("puntos");
            idCategoria = rs.getInt("id_categoria");
            tags = rs.getString("tags");
            archivoUrl = rs.getString("archivo_url");
            autor = rs.getString("username");
        } else {
            response.sendRedirect("index.jsp");
            return;
        }
        rs.close(); ps.close(); con.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    String icono = "🎯", catNombre = "General";
    if (idCategoria == 1) { icono = "🔄"; catNombre = "Reversing"; }
    else if (idCategoria == 2) { icono = "🔐"; catNombre = "Crypto"; }
    else if (idCategoria == 3) { icono = "🧩"; catNombre = "Blockchain"; }
    
    String diffClass = "diff-badge--" + dificultad.toLowerCase();
%>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>DevFlag – <%= titulo %></title>
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="styles.css"/>
  <link rel="stylesheet" href="challenge.css"/>
</head>
<body>
  
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-icon">&lt;/&gt;</div>
      <div class="logo-text">Dev<span>Flag</span></div>
    </div>
    <nav class="nav">
      <a href="index.jsp" class="nav-item active">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M3 12L12 3l9 9"/><path d="M9 21V12h6v9"/>
        </svg>
        Home
      </a>
      <a href="dashboard.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
        </svg>
        Dashboard
      </a>
      <a href="ranking.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/>
        </svg>
        Ranking
      </a>
    </nav>
    </nav>
    <div class="sidebar-footer">
      <div class="profile-menu">
        <div class="profile-dropdown">
          <a href="profile.jsp" class="nav-item">
            <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
              <circle cx="12" cy="7" r="4"/>
            </svg>
            My Profile
          </a>
          <a href="LogoutServlet" class="nav-item" style="color: #e8445a;">
            <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Logout
          </a>
        </div>
      </div>
    </div>
  </aside>
  
  <main class="main">
    <header class="topbar">
      <div class="breadcrumb">
        <a href="index.jsp" class="home-link">Home</a>
        <span class="breadcrumb-sep">/</span>
        <strong><%= titulo %></strong>
      </div>
    </header>
    
    <div class="detail-layout">
      <div class="detail-main">
        
        <div class="challenge-hero">
          <div class="hero-illus"><%= icono %></div>
          <div class="hero-body">
            <div class="hero-meta-top">
              <span class="diff-badge <%= diffClass %>"><%= dificultad.toUpperCase() %></span>
              <span class="cat-badge"><%= catNombre %></span>
              <% if (tags != null && !tags.isEmpty()) { 
                  for(String tag : tags.split(",")) { %>
                    <span class="tag-chip"><%= tag.trim() %></span>
              <% } } %>
            </div>
            <h1 class="hero-title"><%= titulo %></h1>
          </div>
        </div>
        
        <div class="stats-row">
          <div class="stat-chip">
            <span class="stat-chip-val"><%= puntos %> XP</span>
            <span class="stat-chip-label">Reward</span>
          </div>
          <div class="stat-chip">
            <span class="stat-chip-val">0</span>
            <span class="stat-chip-label">Completed</span>
          </div>
        </div>
        
        <div class="detail-section">
          <div class="section-header">
            <span class="section-icon">📋</span>
            <h2 class="section-title">Description</h2>
          </div>
          <div class="section-body prose">
            <p><%= descripcion %></p>
          </div>
        </div>
        
        <div class="detail-section">
          <div class="section-header">
            <span class="section-icon">🚩</span>
            <h2 class="section-title">Submit Flag</h2>
          </div>

          <% if ("flag_correcta".equals(successMsg)) { %>
            <div class="alert alert--success" style="margin-bottom: 16px;">✓ ¡Flag Correcta! Puntos añadidos.</div>
          <% } else if ("flag_incorrecta".equals(errorMsg)) { %>
            <div class="alert alert--error" style="margin-bottom: 16px;">✗ Flag incorrecta. Sigue intentándolo.</div>
          <% } else if ("ya_resuelto".equals(errorMsg)) { %>
            <div class="alert alert--error" style="margin-bottom: 16px;">⚠️ Ya habías resuelto este reto. No sumas XP extra.</div>
          <% } else if ("fallo_servidor".equals(errorMsg)) { %>
            <div class="alert alert--error" style="margin-bottom: 16px;">✗ Error del servidor.</div>
          <% } %>

          <form action="CheckFlagServlet" method="POST" class="flag-form">
            <input type="hidden" name="idReto" value="<%= idParam %>">
            <div class="flag-input-wrap">
              <input type="text" name="flagSubida" placeholder="devflag{...}" required/>
            </div>
            <button type="submit" class="btn-submit-flag">Submit</button>
          </form>
        </div>
      </div>
      
      <aside class="detail-side">
<% if (archivoUrl != null && !archivoUrl.trim().isEmpty()) { 
            // Truco para limpiar el nombre: Cortar todo lo que hay hasta el primer '_'
            String nombreLimpio = archivoUrl;
            if (archivoUrl.contains("_")) {
                nombreLimpio = archivoUrl.substring(archivoUrl.indexOf('_') + 1);
            }
        %>
        <div class="side-panel">
          <div class="side-panel-title">Challenge File</div>
          <div class="file-card">
            <div class="file-card-info">
              <span class="file-card-name"><%= nombreLimpio %></span>
            </div>
          </div>
          <a href="<%= archivoUrl %>" class="btn-download" download="<%= nombreLimpio %>">Download File</a>
        </div>
        <% } %>
        
        <div class="side-panel">
          <div class="side-panel-title">Challenge Info</div>
          <ul class="info-list">
            <li class="info-row"><span class="info-key">Author</span><span class="info-val">@<%= autor %></span></li>
            <li class="info-row"><span class="info-key">Points</span><span class="info-val xp-val"><%= puntos %> XP</span></li>
          </ul>
        </div>
      </aside>
    </div>
  </main>
</body>
</html>