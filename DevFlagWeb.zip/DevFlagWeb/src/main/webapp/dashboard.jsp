<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); 
    response.setHeader("Pragma", "no-cache"); 
    response.setDateHeader("Expires", 0);

    if (session == null || session.getAttribute("usuarioLogueado") == null) {
        response.sendRedirect("login.html");
        return;
    }
    
    String username = (String) session.getAttribute("usuarioLogueado");

    int totalXP = 0;
    int ranking = 0;
    int retosCompletados = 0; 
    int pctReversing = 0;
    int pctStego = 0;
    int pctCrypto = 0;
    int idUsuario = -1;

    String url = "jdbc:mariadb://localhost:3306/devflag";
    String userDB = "netbeans";
    String passDB = "12345";

    try {
        Class.forName("org.mariadb.jdbc.Driver");
        Connection con = DriverManager.getConnection(url, userDB, passDB);

        String sqlRanking = "SELECT id, xp, challenges_completados, posicion FROM v_ranking WHERE username = ?";
        PreparedStatement psRank = con.prepareStatement(sqlRanking);
        psRank.setString(1, username);
        ResultSet rsRank = psRank.executeQuery();
        
        if (rsRank.next()) {
            idUsuario = rsRank.getInt("id");
            totalXP = rsRank.getInt("xp");
            retosCompletados = rsRank.getInt("challenges_completados");
            ranking = rsRank.getInt("posicion");
        }
        rsRank.close(); psRank.close();

        if (idUsuario != -1) {
            String sqlProg = "SELECT categoria, porcentaje FROM v_progreso_categoria WHERE id_usuario = ?";
            PreparedStatement psProg = con.prepareStatement(sqlProg);
            psProg.setInt(1, idUsuario);
            ResultSet rsProg = psProg.executeQuery();
            
            while (rsProg.next()) {
                String cat = rsProg.getString("categoria");
                int pct = rsProg.getInt("porcentaje");
                
                if ("Reversing".equalsIgnoreCase(cat)) {
                    pctReversing = pct;
                } else if ("Crypto".equalsIgnoreCase(cat) || "Cryptography".equalsIgnoreCase(cat)) {
                    pctCrypto = pct;
                } else if ("Steganography".equalsIgnoreCase(cat)) {
                    pctStego = pct;
                }
            }
            rsProg.close(); psProg.close();
        }

        con.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>DevFlag – Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="styles.css"/>
  <link rel="stylesheet" href="dashboard.css"/>
</head>
<body>

  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-icon">&lt;/&gt;</div>
      <div class="logo-text">Dev<span>Flag</span></div>
    </div>

    <nav class="nav">
      <a href="index.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M3 12L12 3l9 9"/><path d="M9 21V12h6v9"/>
        </svg>
        Home
      </a>
      <a href="dashboard.jsp" class="nav-item active">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
        </svg>
        Dashboard
      </a>
      <a href="ranking.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/>
        </svg>
        Ranking
      </a>
    </nav>

    <div class="sidebar-footer">
      <div class="profile-menu">
        <div class="profile-dropdown">
          <a href="profile.jsp" class="nav-item">
            <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
              <circle cx="12" cy="7" r="4"/>
            </svg>
            My Profile
        </a>
        <a href="LogoutServlet" class="nav-item" style="color: #e8445a;">
           <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Logout
          </a>
        </div>
      </div>
    </div>
  </aside>

  <main class="main">

    <header class="topbar">
      <div class="breadcrumb">
        <a href="index.jsp" class="home-link">Home</a>
        <span class="breadcrumb-sep">/</span>
        <strong>Dashboard</strong>
      </div>
    </header>

    <div class="dash-stats">

      <div class="stat-card">
        <div class="stat-icon stat-icon--blue">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M14.5 10c-.83 0-1.5-.67-1.5-1.5v-5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5z"/>
            <path d="M20.5 10H19V8.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
            <path d="M9.5 14c.83 0 1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5S8 21.33 8 20.5v-5c0-.83.67-1.5 1.5-1.5z"/>
            <path d="M3.5 14H5v1.5c0 .83-.67 1.5-1.5 1.5S2 16.33 2 15.5 2.67 14 3.5 14z"/>
            <path d="M14 14.5c0-.83.67-1.5 1.5-1.5h5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5h-5c-.83 0-1.5-.67-1.5-1.5z"/>
            <path d="M15.5 19H14v1.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5-.67-1.5-1.5-1.5z"/>
            <path d="M10 9.5C10 8.67 9.33 8 8.5 8h-5C2.67 8 2 8.67 2 9.5S2.67 11 3.5 11h5c.83 0 1.5-.67 1.5-1.5z"/>
            <path d="M8.5 5H10V3.5C10 2.67 9.33 2 8.5 2S7 2.67 7 3.5 7.67 5 8.5 5z"/>
          </svg>
        </div>
        <div class="stat-info">
          <div class="stat-value"><%= retosCompletados %></div>
          <div class="stat-label">Challenges Completed</div>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon stat-icon--green">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
          </svg>
        </div>
        <div class="stat-info">
          <div class="stat-value"><%= totalXP %> <span class="stat-unit">XP</span></div>
          <div class="stat-label">Total Points</div>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon stat-icon--orange">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/>
          </svg>
        </div>
        <div class="stat-info">
          <div class="stat-value">#<%= ranking %></div>
          <div class="stat-label">Global Ranking</div>
        </div>
      </div>
    </div>

    <div class="dash-grid"> 
      <div class="dash-panel dash-panel--wide">
        <div class="panel-header">
          <span class="panel-title">Progress by Category</span>
        </div>
        <ul class="progress-list">
          <li class="progress-item">
            <div class="progress-top">
              <span class="progress-label">Reversing</span>
              <span class="progress-pct"><%= pctReversing %>%</span>
            </div>
            <div class="progress-track">
              <div class="progress-bar progress-bar--blue" style="width: <%= pctReversing %>%"></div>
            </div>
          </li>
          <li class="progress-item">
            <div class="progress-top">
              <span class="progress-label">Steganography</span>
              <span class="progress-pct"><%= pctStego %>%</span>
            </div>
            <div class="progress-track">
              <div class="progress-bar progress-bar--green" style="width: <%= pctStego %>%"></div>
            </div>
          </li>
          <li class="progress-item">
            <div class="progress-top">
              <span class="progress-label">Cryptography</span>
              <span class="progress-pct"><%= pctCrypto %>%</span>
            </div>
            <div class="progress-track">
              <div class="progress-bar progress-bar--red" style="width: <%= pctCrypto %>%"></div>
            </div>
          </li>
        </ul>
      </div>
    </div>

  </main>
</body>
</html>