<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>DevFlag – Home</title>
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="styles.css"/>
</head>
<body>

  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-icon">&lt;/&gt;</div>
      <div class="logo-text">Dev<span>Flag</span></div>
    </div>

    <nav class="nav">
      <a href="index.jsp" class="nav-item active">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M3 12L12 3l9 9"/><path d="M9 21V12h6v9"/>
        </svg>
        Home
      </a>
      <a href="dashboard.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
        </svg>
        Dashboard
      </a>
      <a href="ranking.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/>
        </svg>
        Ranking
      </a>
    </nav>

    <div class="sidebar-footer">
      <% if (session.getAttribute("usuarioLogueado") != null) { %>
          <div class="profile-menu">
            <div class="profile-dropdown">
              <a href="profile.jsp" class="nav-item">
                <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
                  <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
                My Profile
            </a>
            <a href="LogoutServlet" class="nav-item" style="color: #e8445a;">
                <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
                  <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                  <polyline points="16 17 21 12 16 7"/>
                  <line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
                Logout
              </a>
          </div>
        </div>
      <% } else { %>
        <a href="login.html" class="btn-auth btn-login">Login</a>
        <a href="signup.html" class="btn-auth btn-register">Register</a>
      <% } %>
    </div>
  </aside>

  <main class="main">
    <header class="topbar">
      <div class="breadcrumb">
        <span><a href="index.jsp" class="home-link">Home</a></span>
      </div>
      <a href="addChallenge.jsp" class="btn-add">
        <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/>
        </svg>
        Add Challenge
      </a>
    </header>

    <div class="filters-bar">
      <div class="filter-select">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <line x1="4" y1="6" x2="16" y2="6"/><line x1="4" y1="12" x2="12" y2="12"/><line x1="4" y1="18" x2="8" y2="18"/>
        </svg>
        Select Filter
        <svg class="chevron" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </div>
      <div class="search-box">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input type="text" placeholder="Search by Name" />
      </div>
    </div>

    <section class="cards-grid">
      <%
          String url = "jdbc:mariadb://localhost:3306/devflag";
          String userDB = "netbeans";
          String passDB = "12345";

          try {
              Class.forName("org.mariadb.jdbc.Driver");
              Connection con = DriverManager.getConnection(url, userDB, passDB);
              
              String sql = "SELECT id, titulo, descripcion, dificultad, puntos, id_categoria FROM Reto ORDER BY id DESC";
              PreparedStatement ps = con.prepareStatement(sql);
              ResultSet rs = ps.executeQuery();

              while (rs.next()) {
                  int idReto = rs.getInt("id");
                  String titulo = rs.getString("titulo");
                  String descripcion = rs.getString("descripcion");
                  String dificultad = rs.getString("dificultad");
                  int puntos = rs.getInt("puntos");
                  int idCategoria = rs.getInt("id_categoria");

                  if (descripcion != null && descripcion.length() > 75) {
                      descripcion = descripcion.substring(0, 72) + "...";
                  }

                  String icono = "🎯";
                  if (idCategoria == 1) icono = "🔄";
                  else if (idCategoria == 2) icono = "🔐";
                  else if (idCategoria == 3) icono = "🧩";

                  String diffClass = "difficulty-medium";
                  String diffCapitalized = "Medium";
                  if ("easy".equalsIgnoreCase(dificultad)) {
                      diffClass = "difficulty-easy";
                      diffCapitalized = "Easy";
                  } else if ("hard".equalsIgnoreCase(dificultad)) {
                      diffClass = "difficulty-hard";
                      diffCapitalized = "Hard";
                  }
      %>
      
      <article class="card" onclick="window.location='challenge.jsp?id=<%= idReto %>'" style="cursor:pointer">
        <div class="card-header">
          <div class="card-illustration"><span class="puzzle"><%= icono %></span></div>
          <div class="card-actions">
            <button class="btn-icon">
              <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>
              </svg>
            </button>
            <button class="btn-icon">
              <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z"/>
              </svg>
            </button>
          </div>
        </div>
        <div class="card-body">
          <div class="card-title"><%= titulo %></div>
          <div class="card-desc"><%= descripcion %></div>
          <div class="card-meta">
            <span class="meta-label">Difficulty:</span>
            <span class="meta-label">Completed by:</span>
            <span class="meta-label">Points:</span>
            <span class="meta-value <%= diffClass %>"><%= diffCapitalized %></span>
            <span class="meta-value">0 users</span>
            <span class="meta-value xp"><%= puntos %> XP</span>
          </div>
        </div>
      </article>

      <%
              }
              rs.close();
              ps.close();
              con.close();
          } catch (Exception e) {
              out.println("<p style='color:red;'>Error al cargar los retos: " + e.getMessage() + "</p>");
          }
      %>
    </section>
  </main>
</body>
</html>