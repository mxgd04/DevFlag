<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("usuarioLogueado") == null) {
        response.sendRedirect("login.html");
        return;
    }
    String username = (String) session.getAttribute("usuarioLogueado");
    String email    = (String) session.getAttribute("emailUsuario");
    if (email == null) email = "";

    String success = request.getParameter("success");
    String error   = request.getParameter("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>DevFlag – Profile</title>
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="styles.css"/>
  <link rel="stylesheet" href="profile.css"/>
</head>
<body>

  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-icon">&lt;/&gt;</div>
      <div class="logo-text">Dev<span>Flag</span></div>
    </div>
    <nav class="nav">
      <a href="index.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="18" height="18">
          <path d="M3 12L12 3l9 9"/><path d="M9 21V12h6v9"/>
        </svg>
        Home
      </a>
      <a href="dashboard.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="18" height="18">
          <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
        </svg>
        Dashboard
      </a>
      <a href="ranking.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="18" height="18">
          <path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/>
        </svg>
        Ranking
      </a>
    </nav>
    <div class="sidebar-footer">
      <div class="profile-menu">
        <div class="profile-dropdown">
          <a href="profile.jsp" class="nav-item">
            <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
              <circle cx="12" cy="7" r="4"/>
            </svg>
            My Profile
          </a>
          <a href="LogoutServlet" class="nav-item" style="color: #e8445a;">
            <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Logout
          </a>
        </div>
      </div>
    </div>
  </aside>

  <main class="main">
    <header class="topbar">
      <div class="breadcrumb">
        <a href="index.jsp" class="home-link">Home</a>
        <span class="breadcrumb-sep">/</span>
        <strong>Profile</strong>
      </div>
    </header>

    <div class="profile-wrap">
      <% if ("username_updated".equals(success)) { %>
        <div class="alert alert--success">✓ Username updated successfully.</div>
      <% } else if ("password_updated".equals(success)) { %>
        <div class="alert alert--success">✓ Password updated successfully.</div>
      <% } else if ("passwords_no_coinciden".equals(error)) { %>
        <div class="alert alert--error">✗ Passwords do not match.</div>
      <% } else if ("wrong_password".equals(error)) { %>
        <div class="alert alert--error">✗ Current password is incorrect.</div>
      <% } else if ("username_taken".equals(error)) { %>
        <div class="alert alert--error">✗ That username is already taken.</div>
      <% } else if ("fallo_interno".equals(error)) { %>
        <div class="alert alert--error">✗ Server error. Please try again.</div>
      <% } %>

      <div class="profile-card">
        <div class="profile-card-header">
          <div class="profile-big-avatar">👤</div>
          <div class="profile-card-info">
            <div class="profile-card-name"><%= username %></div>
            <div class="profile-card-email"><%= email %></div>
            <span class="profile-badge">Member</span>
          </div>
        </div>
      </div>

      <div class="profile-grid">
        <div class="profile-section">
          <div class="profile-section-header">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <polyline points="16 18 22 12 16 6"/>
              <polyline points="8 6 2 12 8 18"/>
            </svg>
            <h2>Change Username</h2>
          </div>
          <form action="ProfileServlet" method="post">
            <input type="hidden" name="action" value="changeUsername"/>
            <div class="pf-group">
              <label for="new-username">New Username</label>
              <div class="pf-input-wrap">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
                <input type="text" id="new-username" name="newUsername" placeholder="new_username" required value="<%= username %>"/>
              </div>
            </div>
            <div class="pf-group">
              <label for="current-pass-u">Current Password</label>
              <div class="pf-input-wrap">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0110 0v4"/>
                </svg>
                <input type="password" id="current-pass-u" name="currentPassword" placeholder="••••••••" required/>
              </div>
            </div>
            <button type="submit" class="btn-pf-submit">
              <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              Save Username
            </button>
          </form>
        </div>

        <div class="profile-section">
          <div class="profile-section-header">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
              <path d="M7 11V7a5 5 0 0110 0v4"/>
            </svg>
            <h2>Change Password</h2>
          </div>
          <form action="ProfileServlet" method="post">
            <input type="hidden" name="action" value="changePassword"/>
            <div class="pf-group">
              <label for="current-pass-p">Current Password</label>
              <div class="pf-input-wrap">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0110 0v4"/>
                </svg>
                <input type="password" id="current-pass-p" name="currentPassword" placeholder="••••••••" required/>
              </div>
            </div>
            <div class="pf-group">
              <label for="new-pass">New Password</label>
              <div class="pf-input-wrap">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0110 0v4"/>
                </svg>
                <input type="password" id="new-pass" name="newPassword" placeholder="••••••••" required/>
              </div>
            </div>
            <div class="pf-group">
              <label for="confirm-pass">Confirm New Password</label>
              <div class="pf-input-wrap">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0110 0v4"/>
                </svg>
                <input type="password" id="confirm-pass" name="confirmPassword" placeholder="••••••••" required/>
              </div>
            </div>
            <button type="submit" class="btn-pf-submit">
              <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              Save Password
            </button>
          </form>
        </div>
      </div>
    </div>
  </main>

</body>
</html>