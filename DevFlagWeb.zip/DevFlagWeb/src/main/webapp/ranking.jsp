<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Guardia de seguridad (Opcional, pero recomendado para que no coticen sin cuenta)
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); 
    response.setHeader("Pragma", "no-cache"); 
    response.setDateHeader("Expires", 0);

    if (session == null || session.getAttribute("usuarioLogueado") == null) {
        response.sendRedirect("login.html");
        return;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>DevFlag – Ranking</title>
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="styles.css"/>
  <link rel="stylesheet" href="ranking.css"/>
</head>
<body>

  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-icon">&lt;/&gt;</div>
      <div class="logo-text">Dev<span>Flag</span></div>
    </div>
    <nav class="nav">
      <a href="index.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M3 12L12 3l9 9"/><path d="M9 21V12h6v9"/>
        </svg>
        Home
      </a>
      <a href="dashboard.jsp" class="nav-item">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
        </svg>
        Dashboard
      </a>
      <a href="ranking.jsp" class="nav-item active">
        <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/>
        </svg>
        Ranking
      </a>
    </nav>
    <div class="sidebar-footer">
      <div class="profile-menu">
        <div class="profile-dropdown">
          <a href="profile.jsp" class="nav-item">
            <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
              <circle cx="12" cy="7" r="4"/>
            </svg>
            My Profile
          </a>
          <a href="LogoutServlet" class="nav-item" style="color: #e8445a;">
            <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Logout
          </a>
        </div>
      </div>
    </div>
  </aside>

  <main class="main">

    <header class="topbar">
      <div class="breadcrumb">
        <a href="index.jsp" class="home-link">Home</a>
        <span class="breadcrumb-sep">/</span>
        <strong>Ranking</strong>
      </div>
    </header>

    <div class="ranking-wrap">
      <div class="search-wrap">
        <label class="search-box" for="search-input">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input type="search" id="search-input" placeholder="Search by username…" />
        </label>
      </div>

      <div class="ranking-table-wrap">
        <table class="ranking-table">
          <thead>
            <tr>
              <th class="col-rank">Rank</th>
              <th class="col-user">Player</th>
              <th class="col-solves">Challenges</th>
              <th class="col-xp">XP</th>
            </tr>
          </thead>
          <tbody>

            <%
                String url = "jdbc:mariadb://localhost:3306/devflag";
                String userDB = "netbeans";
                String passDB = "12345";

                try {
                    Class.forName("org.mariadb.jdbc.Driver");
                    Connection con = DriverManager.getConnection(url, userDB, passDB);
                    
                    String sql = "SELECT username, xp, challenges_completados, posicion FROM v_ranking ORDER BY posicion ASC";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ResultSet rs = ps.executeQuery();
                    
                    int maxXP = -1;

                    while (rs.next()) {
                        String player = rs.getString("username");
                        int xp = rs.getInt("xp");
                        int solves = rs.getInt("challenges_completados");
                        int pos = rs.getInt("posicion");

                        if (maxXP == -1) {
                            maxXP = (xp > 0) ? xp : 1; 
                        }

                        int pct = (int) Math.round(((double) xp / maxXP) * 100);

                        String rowClass = "";
                        String rankLabel = "#" + pos;
                        String avatar = "👤";

                        if (pos == 1) {
                            rowClass = "row-gold";
                            rankLabel = "🥇";
                            avatar = "👤";
                        } else if (pos == 2) {
                            rowClass = "row-silver";
                            rankLabel = "🥈";
                            avatar = "👤";
                        } else if (pos == 3) {
                            rowClass = "row-bronze";
                            rankLabel = "🥉";
                            avatar = "👤";
                        } else if (pos % 2 == 0) {
                            rowClass = "row-even";
                        }
            %>

            <tr class="rank-row <%= rowClass %>">
              <td class="col-rank"><span class="rank-label"><%= rankLabel %></span></td>
              <td class="col-user"><span class="player-avatar"><%= avatar %></span><span class="player-name"><%= player %></span></td>
              <td class="col-solves"><span class="solves-val"><%= solves %></span></td>
              <td class="col-xp">
                <span class="xp-bar-wrap"><span class="xp-bar" style="--pct:<%= pct %>%"></span></span>
                <span class="xp-val"><%= xp %> XP</span>
              </td>
            </tr>

            <%
                    }
                    rs.close();
                    ps.close();
                    con.close();
                } catch (Exception e) {
                    out.println("<tr><td colspan='4' style='color:red; text-align:center;'>Error al cargar el ranking: " + e.getMessage() + "</td></tr>");
                }
            %>

          </tbody>
        </table>
      </div>
    </div>
  </main>

</body>
</html>